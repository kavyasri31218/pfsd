from django.urls import path,include
from .views import sample1,sample2,sample3,sample4,register,sample6
urlpatterns=[
    path('',sample1,name='NR'),
    path('contactus/',sample2,name='DR1'),
    path('services/',sample3,name='DR2'),
    path('purchases/',sample4,name='DR3'),
    path('register/', register, name='register'),
    path('sigin/', sample6, name='DR4'),

]