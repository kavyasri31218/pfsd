from django.http import HttpResponse
from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.template import loader




# Create your views here.

def sample1(request):
    return render(request,"home.html")

def index(request):
  mymembers = Member.objects.all().values()
  template = loader.get_template('index.html')
  context = {
    'mymembers': mymembers,
  }
  return HttpResponse(template.render(context, request))
def add(request):
  template = loader.get_template('add.html')
  return HttpResponse(template.render({}, request))

def addrecord(request):
  x = request.POST['first']
  y = request.POST['last']
  member = Members(firstname=x, lastname=y)
  member.save()
  return HttpResponseRedirect(reverse('index'))

def sample2(request):
    return render(request, 'contact.html')

def sample3(request):
    return render(request,"services.html")

def sample4(request):
    return render(request,"purchases.html")

def register(request):
    return render(request,"register.html")
def sample6(request):
    return render(request,"signin.html")